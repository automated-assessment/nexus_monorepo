function testall() 
    disp('Test Integrate Monte Carlo 1');
    testIntegrateMonteCarlo();
    disp('End of tests');
end    