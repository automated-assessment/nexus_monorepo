function timeout()
    disp("Pausing");
    pause(60);