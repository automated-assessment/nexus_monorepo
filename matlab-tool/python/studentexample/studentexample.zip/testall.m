function testall() 
    disp('Test question 1');
    answerProblem();
    disp('End of tests');
end    